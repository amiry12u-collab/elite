# My Netlify Site 🚀

This is a demo project showing how to use **Netlify Functions** with a static site.

## 📂 Folder Structure
```
my-netlify-site/
│── index.html              # Main homepage
│
├── netlify/
│   └── functions/
│       └── fetchdata.js    # Serverless function (API endpoint)
│
└── assets/
    └── style.css           # Styling
```

## ⚡ How it works
1. Open `index.html` → it loads the frontend.
2. On page load, JavaScript calls the Netlify Function:
   ```
   /.netlify/functions/fetchdata
   ```
3. The function returns JSON data → which gets displayed in the browser.

## 🌐 Deploy on Netlify
1. Create a new repository (GitHub/GitLab/Bitbucket) and push this code.
2. Go to [Netlify](https://app.netlify.com/) → New Site → Import your repo.
3. Make sure Netlify detects the **functions folder** automatically (default: `netlify/functions`).
4. Deploy! 🚀
5. Open your site:
   ```
   https://your-site-name.netlify.app
   ```

## ✅ Example API Response
```json
{
  "success": true,
  "message": "Hello from Netlify Function 🚀",
  "timestamp": "2025-09-29T12:34:56.789Z",
  "items": [
    { "id": 1, "name": "Alpha", "value": 100 },
    { "id": 2, "name": "Beta", "value": 200 },
    { "id": 3, "name": "Gamma", "value": 300 }
  ]
}
```

---
© 2025 Elite Fund. All rights reserved.
