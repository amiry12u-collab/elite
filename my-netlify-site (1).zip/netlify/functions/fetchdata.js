// netlify/functions/fetchdata.js

export async function handler(event, context) {
  try {
    const data = {
      success: true,
      message: "Hello from Netlify Function 🚀",
      timestamp: new Date().toISOString(),
      items: [
        { id: 1, name: "Alpha", value: 100 },
        { id: 2, name: "Beta", value: 200 },
        { id: 3, name: "Gamma", value: 300 },
      ],
    };

    return {
      statusCode: 200,
      body: JSON.stringify(data),
      headers: { "Content-Type": "application/json" },
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, error: error.message }),
    };
  }
}
